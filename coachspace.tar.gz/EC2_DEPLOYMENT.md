# EC2 Deployment

This project can run on one EC2 instance with Docker. Keep it to one instance while it uses SQLite. Before scaling horizontally, move the database to RDS Postgres and store uploaded media in S3.

## 1. Launch The Instance

Use an Amazon Linux EC2 instance.

Suggested starter settings:

- Instance type: `t3.small`
- Storage: 20 GB or more
- Security group inbound rules:
  - SSH `22` from your IP only
  - HTTP `80` from `0.0.0.0/0`
  - HTTPS `443` from `0.0.0.0/0` when you add TLS

## 2. Install Docker

SSH into the instance and run:

```bash
sudo yum update -y
sudo yum install -y docker
sudo systemctl enable --now docker
sudo usermod -aG docker ec2-user
```

Log out and SSH back in so the Docker group takes effect.

## 3. Copy The Project To EC2

From your local machine, create a clean archive that does not include `.venv`, databases, uploads, or the bundled AWS CLI files:

```bash
tar --exclude='.venv' --exclude='data' --exclude='uploads/*' --exclude='aws' --exclude='awscliv2.zip' --exclude='coachspace.zip' -czf coachspace.tar.gz .
scp -i your-key.pem coachspace.tar.gz ec2-user@YOUR_EC2_PUBLIC_IP:/home/ec2-user/
```

On EC2:

```bash
mkdir -p ~/coachspace
tar -xzf ~/coachspace.tar.gz -C ~/coachspace
cd ~/coachspace
cp .env.ec2.example .env.ec2
```

Edit `.env.ec2` and set a real `APP_SECRET`.

Generate one with:

```bash
openssl rand -hex 32
```

## 4. Run The App

```bash
docker build -t coachspace .
docker volume create coachspace-data
docker volume create coachspace-uploads
docker rm -f coachspace 2>/dev/null || true
docker run -d \
  --name coachspace \
  --restart unless-stopped \
  -p 80:8000 \
  --env-file .env.ec2 \
  -v coachspace-data:/app/data \
  -v coachspace-uploads:/app/uploads \
  coachspace
```

Check it:

```bash
docker ps
curl http://localhost/health
```

Then open:

```text
http://YOUR_EC2_PUBLIC_IP
```

## 5. Update The App

Copy a fresh archive to EC2, extract it over `~/coachspace`, then run:

```bash
cd ~/coachspace
docker build -t coachspace .
docker rm -f coachspace
docker run -d \
  --name coachspace \
  --restart unless-stopped \
  -p 80:8000 \
  --env-file .env.ec2 \
  -v coachspace-data:/app/data \
  -v coachspace-uploads:/app/uploads \
  coachspace
```

The SQLite database and local uploads are stored in Docker volumes named `coachspace-data` and `coachspace-uploads`, so they survive container rebuilds.

## 6. Production Notes

- Set `APP_SECRET` before exposing the app publicly.
- Use S3 for uploaded videos/audio/PDFs before real users rely on the app.
- Add a domain and HTTPS with Nginx plus Let's Encrypt, or put an AWS Application Load Balancer in front of the instance.
- Keep only one EC2 instance until SQLite is replaced by RDS Postgres.
